
int connectivity_status() {
    return 1;
}