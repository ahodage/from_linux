#include "status.h"

int test_connectivity();
