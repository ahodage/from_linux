int db_connect() {
    return 0;
}

void db_disconnect() {
    
}