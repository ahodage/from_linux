int db_connect();
void db_disconnect();