int file_thingy() {
    return 0;
}